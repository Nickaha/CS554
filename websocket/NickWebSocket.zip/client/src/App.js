//Nick Guo
import React, { useEffect, useRef, useState } from 'react';
import io from 'socket.io-client';
import './App.css';

function App() {
  const [state, setState] = useState({ message: '', name: '', room: '' });
  const [chat, setChat] = useState([]);

  const socketRef = useRef();

  useEffect(() => {
    socketRef.current = io('/');
    return () => {
      socketRef.current.disconnect();
    };
  }, []);

  useEffect(() => {
    socketRef.current.on('message', ({ name, message, room }) => {
      setChat([...chat, { name, message, room }]);
    });
    socketRef.current.on('user_join', function (data) {
      setChat([
        ...chat,
        { name: 'ChatBot', message: `${data.name} has joined the chat room ${data.room}` }
      ]);
    });
    socketRef.current.on('user_leave', function (data) {
      setChat([
        ...chat,
        { name: 'ChatBot', message: `${data.name} has left the chat ${data.room}` }
      ]);
    });
  }, [chat]);

  const userjoin = (name, room) => {
    socketRef.current.emit('user_join', {name, room});
    setState({...state,name:name, room:room});
    console.log(state);
  };

  const onMessageSubmit = (e) => {
    let msgEle = document.getElementById('message');
    console.log([msgEle.name], msgEle.value);
    setState({ ...state, [msgEle.name]: msgEle.value });
    socketRef.current.emit('message', {
      name: state.name,
      message: msgEle.value,
      room: state.room
    });
    e.preventDefault();
    setState({ message: '', name: state.name, room:state.room });
    msgEle.value = '';
    msgEle.focus();
  };

  const renderChat = () => {
    return chat.map(({ name, message, room }, index) => (
      <div key={index}>
        <h3>
          {room} -- {name}: <span>{message}</span>
        </h3>
      </div>
    ));
  };

  const changeRoom = (e) =>{
    e.preventDefault();

    let room = document.getElementById('room_select').value;
    if (state.room !== room){
      console.log(`Room changed from ${state.room} to ${room}`);
      setState({...state, room});
      socketRef.current.emit('change_room', {name: state.name, old_room: state.room, new_room: room});
    }
    
  }

  return (
    <div>
      {state.name && (
        <div className="card">
          <div className="render-chat">
            <h1>Chat Log: {state.room}</h1>
            {renderChat()}
          </div>
          <form onSubmit={onMessageSubmit}>
            <h1>Messenge</h1>
            <div>
              <input
                name="message"
                id="message"
                variant="outlined"
                label="Message"
              />
            </div>
            <button>Send Message</button>
          </form>


          <form onSubmit={changeRoom}>
            <label>Pick a room to join:
              <br />
              <select name="rooms" id="room_select">
                <option value="room1">Room 1</option>
                <option value="room2">Room 2</option>
                <option value="room3">Room 3</option>
                <option value="room3">Room 4</option>
              </select>
              <button>Change Room</button>
            </label>

          </form>
        </div>
      )}

      {!state.name && (
        <form
          className="form"
          onSubmit={(e) => {
            console.log(document.getElementById('username_input').value);
            e.preventDefault();
            //setState({ name: document.getElementById('username_input').value });
            console.log(state);
            //userjoin(document.getElementById('username_input').value, "room2");
            userjoin(document.getElementById('username_input').value, document.getElementById('room_select').value);
            console.log(state);
          }}
        >
          <div className="form-group">
            <label>
              User Name:
              <br />
              <input id="username_input" />
            </label>
          </div>
          <br />
          <label>Choose a room:
            <br />
            <select name="rooms" id="room_select">
              <option value="room1">Room 1</option>
              <option value="room2">Room 2</option>
              <option value="room3">Room 3</option>
            </select>
          </label>
          <br />
          <br />
          <button type="submit"> Click to join</button>
        </form>
      )}
    </div>
  );
}

export default App;