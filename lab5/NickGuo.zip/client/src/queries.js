
import { gql } from '@apollo/client';

const UNSPLASHIMAGES = gql `
    query getUnsplashImages($pageNum: Int){
        unsplashImages(pageNum: $pageNum){
        id
        url
        posterName
        description
        userPosted
        binned
    }
}`;

const BINNEDIMAGES = gql `
    query getBinnedImages{
        binnedImages {
            id
            url
            posterName
            description
            userPosted
            binned
        }
}`;

const USERPOSTEDIMAGES = gql `
    query getUserPosts{
        userPostedImages {
            id
            url
            posterName
            description
            userPosted
            binned
        }
}`;

const GETTOPTENBINNEDPOSTS = gql `
    query getTenPosts{
        getTopTenBinnedPosts{
            id
            url
            posterName
            description
            userPosted
            binned
            numBinned
        }
    }
`;

const UPLOADIMAGE = gql `
mutation createImage($url: String!, $description: String, $posterName: String) {
    uploadImage(url: $url, description: $description, posterName: $posterName) {
        id
        url
        posterName
        description
        userPosted
        binned
    }
}`;

const UPDATEIMAGE = gql `
mutation updateImage($id: ID!, $url: String, $description: String, $posterName: String, $binned: Boolean, $userPosted: Boolean) {
    updateImage(id: $id, url: $url, description: $description, posterName: $posterName, binned: $binned, userPosted: $userPosted) {
        id
        url
        posterName
        description
        userPosted
        binned
    }
}`;

const DELETEIMAGE = gql`
mutation deletePost($id: ID!) {
    deleteImage(id: $id) {
        id
        url
        posterName
        description
        userPosted
        binned
    }
}`;

let exported = {
    UNSPLASHIMAGES,
    BINNEDIMAGES,
    USERPOSTEDIMAGES,
    UPLOADIMAGE,
    UPDATEIMAGE,
    DELETEIMAGE,
    GETTOPTENBINNEDPOSTS
};

export default exported;
