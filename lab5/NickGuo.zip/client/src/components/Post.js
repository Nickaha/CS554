import React from 'react';
import './App.css';
import noImage from '../download.jpeg';
import { useMutation, useQuery } from '@apollo/client';
import queries from '../queries';
import { Link } from 'react-router-dom';
import {
  Card,
  CardContent,
  CardMedia,
  Grid,
  Typography,
  makeStyles
} from '@material-ui/core';
const useStyles = makeStyles({
  card: {
    maxWidth: 260,
    height: 'auto',
    marginLeft: 'auto',
    marginRight: 'auto',
    borderRadius: 5,
    border: '1px solid #007b6d',
    boxShadow: '0 19px 38px rgba(0,0,0,0.30), 0 15px 12px rgba(0,0,0,0.22);'
  },
  titleHead: {
    borderBottom: '1px solid #007b6d',
    fontWeight: 'bold'
  },
  grid: {
    flexGrow: 1,
    flexDirection: 'row'
  },
  media: {
    height: '300px',
    width: '100%'
  },
  button: {
    color: '#007b6d',
    fontWeight: 'bold',
    marginLeft: '10px',
    fontSize: 15,
  }
});

function Post() {
  const regex = /(<([^>]+)>)/gi;
  const classes = useStyles();
  const [removePost] = useMutation(queries.DELETEIMAGE);
  const [addToBin] = useMutation(queries.UPDATEIMAGE);
  const [removeFromBin] = useMutation(queries.UPDATEIMAGE);
  let card = null;

  const AddToBin = (args) =>{
    addToBin({
      variables:{
        id: args.id,
        url : args.url,
        description: args.description,
        posterName: args.posterName,
        userPosted: args.userPosted,
        binned: true
      }
    });
  };
  const RemoveFromBin = (args) => {
    removeFromBin({
        variables: {
        id: args.id,
        url : args.url,
        description: args.description,
        posterName: args.posterName,
        userPosted: args.userPosted,
        binned:false
        }
    })
  };
  const RemovePost = (args) => {
    removePost({
        variables: {
        id: args.id,
        }
    });
  };
  const buildCard = (post) => {
    return (
        <Grid item xs={12} sm={6} md={4} lg={3} xl={2} key={post.id}>
        <Card className={classes.card} variant="outlined">
                <CardMedia
                className={classes.media}
                component="img"
                image={
                    post && post.url
                      ? post.url
                      : noImage
                  }
                title="Post image"
                />
                <CardContent>
                <Typography variant="body2" color="textSecondary" component="p">
                    {post.description
                ? post.description.replace(regex, '')
                : 'No description'}
                </Typography>
                </CardContent>
                <CardContent>
                      <Typography variant='body2' color='textSecondary' component='p'>
                          Author: {post.posterName ? post.posterName : 'No author'}
                      </Typography>
                </CardContent>
                <br />
                { post.binned === true ?
                      <button className={classes.button} onClick={() => {RemoveFromBin(post); window.location.reload()}}> Remove from bin </button>:
                      <button className={classes.button} onClick={() => {AddToBin(post); window.location.reload()}}> Add to bin </button> 
                }
                <button className={classes.button} onClick={() => {RemovePost(post); window.location.reload()}}> Delete post </button>
                <br />
        </Card>
        </Grid>
    );
    };
  const { loading, error, data } = useQuery(queries.USERPOSTEDIMAGES, {
    fetchPolicy: 'cache-and-network'
  });
  let images;
  console.log(data);
  if (data) {
    const { userPostedImages } = data;
    images = userPostedImages;
    //console.log(images);
  }
  
  card = images && images.map((image)=>{
    return buildCard(image);
  });
  if (loading) {
    return <div>Loading</div>;
  } else if (error) {
    return <div>{error.message}</div>;
  } else if (data){
    
    return (
      <div>
          <br />
        <Link className="showlink" to={"/new-post/"}>Create Post</Link>
        <br /><br /><br />
        <br />
        <Grid container className={classes.grid} spacing={5}>
          {card}
        </Grid>
      </div>
    );
  }
}

export default Post;