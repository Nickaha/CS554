import React, {useState} from 'react';
import './App.css';
import noImage from '../download.jpeg';
import { useMutation, useQuery } from '@apollo/client';
import queries from '../queries';
import {
  Card,
  CardActionArea,
  CardContent,
  CardMedia,
  Grid,
  Typography,
  makeStyles
} from '@material-ui/core';
const useStyles = makeStyles({
  card: {
    maxWidth: 260,
    height: 'auto',
    marginLeft: 'auto',
    marginRight: 'auto',
    borderRadius: 5,
    border: '1px solid #007b6d',
    boxShadow: '0 19px 38px rgba(0,0,0,0.30), 0 15px 12px rgba(0,0,0,0.22);'
  },
  titleHead: {
    borderBottom: '1px solid #007b6d',
    fontWeight: 'bold'
  },
  grid: {
    flexGrow: 1,
    flexDirection: 'row'
  },
  media: {
    height: '300px',
    width: '100%'
  },
  button: {
    color: '#007b6d',
    fontWeight: 'bold',
    marginLeft: '10px',
    fontSize: 15,
  }
});

function Home() {
  let images;
  const regex = /(<([^>]+)>)/gi;
  const classes = useStyles();
  const [pageNum, setPageNum] = useState(1);
  const { loading, error, data } = useQuery(queries.UNSPLASHIMAGES, {
    fetchPolicy: 'cache-and-network',
    variables: {pageNum: pageNum}
  });
  if (data) {
    const { unsplashImages } = data;
    images = unsplashImages;
    console.log(images);
  }
  const {loading: loading1, error:error1, data:data1} = useQuery(queries.BINNEDIMAGES,{
    fetchPolicy: 'cache-and-network'
  });
  //console.log(data1);
  let im2;
  if(data1){
    const {binnedImages} = data1;
    im2 = binnedImages;
  }
  const [addToBin] = useMutation(queries.UPDATEIMAGE,{
    update(cache,{data:{ updateImage }}){
      console.log(cache, updateImage);
      const { unsplashImages } = cache.readQuery({query:queries.UNSPLASHIMAGES,variables:{pageNum: pageNum}});
      for (let i of unsplashImages){
          if(i.id === updateImage.id){
            i=updateImage;
          }
      }
      
      images = unsplashImages;
      cache.writeQuery({
        data:{unsplashImages:images},
        query:queries.UNSPLASHIMAGES
      });
      console.log(images, cache);
    }
  });
  const [removeFromBin] = useMutation(queries.UPDATEIMAGE,{
    update(cache,{data:{ updateImage }}){
      const { unsplashImages } = cache.readQuery({query:queries.UNSPLASHIMAGES,variables:{pageNum: pageNum}});
      for (let i of unsplashImages){
          if(i.id === updateImage.id){
            i=updateImage;
          }
      }
      cache.writeQuery({
        query:queries.UNSPLASHIMAGES,
        variables:{pageNum:pageNum},
        data: { unsplashImages: unsplashImages}
      });
      console.log(2);
      console.log(cache);
    }
  });
  let card = null;

  const AddToBin = (args) =>{
    addToBin({
      variables:{
        id: args.id,
        url : args.url,
        description: args.description,
        posterName: args.posterName,
        userPosted: args.userPosted,
        binned: true
      }
    });
  };
  const RemoveFromBin = (args) => {
    removeFromBin({
        variables: {
        id: args.id,
        url : args.url,
        description: args.description,
        posterName: args.posterName,
        userPosted: args.userPosted,
        binned:false
        }
    })
  };
  const handleMorePosts = () =>{
    setPageNum(pageNum+1);
  }
  const buildCard = (post) => {
    //console.log(post);
    // console.log(bin);
    return (
        <Grid item xs={12} sm={6} md={4} lg={3} xl={2} key={post.id}>
        <Card className={classes.card} variant="outlined">
                <CardMedia
                className={classes.media}
                component="img"
                image={
                    post && post.url
                      ? post.url
                      : noImage
                  }
                title="Post image"
                />
                <CardContent>
                <Typography variant="body2" color="textSecondary" component="p">
                    {post.description
                ? post.description.replace(regex, '')
                : 'No description'}
                </Typography>
                </CardContent>
                <CardContent>
                      <Typography variant='body2' color='textSecondary' component='p'>
                          Author: {post.posterName ? post.posterName : 'No author'}
                      </Typography>
                </CardContent>
                <br />
                <p>.</p>
                { post.binned === true ?
                  <button className={classes.button} type="button" onClick={(e) => {e.preventDefault();RemoveFromBin(post)}}> Remove from bin </button> :
                  <button className={classes.button} type="button" onClick={(e) => {e.preventDefault();AddToBin(post)}}> Add to bin </button> 
                }
                <br />
                <br />
        </Card>
        </Grid>
    );
    };
  
  //console.log(data);
  
  
  //console.log(im2);
  card = images && im2 && images.map((image)=>{
    for(const i of im2) {
      //console.log(i);
      //console.log(i.id === image.id);
      if(i.id === image.id) image = i;
    }
    // //console.log(image);
    return buildCard(image);
  });
  if (loading) {
    return <div>Loading</div>;
  } else if (error) {
    return <div>{error.message}</div>;
  } else if(data == null || data.unsplashImages.length === 0){
    return(
      <div>
      There is no unsplash image.
      </div>
    )
  }else if (images){
    //console.log(card);
    return (
      <div>
        <Grid container className={classes.grid} spacing={5}>
          {card}
        </Grid>
        <button className={classes.button} onClick = {handleMorePosts}>Get More</button>
      </div>
    );
  }
}

export default Home;