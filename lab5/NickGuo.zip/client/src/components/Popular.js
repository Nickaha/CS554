import React, {useState} from 'react';
import './App.css';
import noImage from '../download.jpeg';
import { useMutation, useQuery } from '@apollo/client';
import queries from '../queries';
import {
  Card,
  CardContent,
  CardMedia,
  Grid,
  Typography,
  makeStyles
} from '@material-ui/core';
const useStyles = makeStyles({
  card: {
    maxWidth: 260,
    height: 'auto',
    marginLeft: 'auto',
    marginRight: 'auto',
    borderRadius: 5,
    border: '1px solid #007b6d',
    boxShadow: '0 19px 38px rgba(0,0,0,0.30), 0 15px 12px rgba(0,0,0,0.22);'
  },
  titleHead: {
    borderBottom: '1px solid #007b6d',
    fontWeight: 'bold'
  },
  grid: {
    flexGrow: 1,
    flexDirection: 'row'
  },
  media: {
    height: '300px',
    width: '100%'
  },
  button: {
    color: '#007b6d',
    fontWeight: 'bold',
    marginLeft: '10px',
    fontSize: 15,
  }
});

function Popular() {
  const regex = /(<([^>]+)>)/gi;
  const classes = useStyles();
  const [removeFromBin] = useMutation(queries.UPDATEIMAGE);
  let card = null;
  const RemoveFromBin = (args) => {
    removeFromBin({
        variables: {
        id: args.id,
        url : args.url,
        description: args.description,
        posterName: args.posterName,
        userPosted: args.userPosted,
        binned:false
        }
    })
  };
  const buildCard = (post) => {
    return (
        <Grid item xs={12} sm={6} md={4} lg={3} xl={2} key={post.id}>
        <Card className={classes.card} variant="outlined">
                <CardMedia
                className={classes.media}
                component="img"
                image={
                    post && post.url
                      ? post.url
                      : noImage
                  }
                title="Post image"
                />
                <CardContent>
                <Typography variant="body2" color="textSecondary" component="p">
                    {post.description
                ? post.description.replace(regex, '')
                : 'No description'}
                </Typography>
                </CardContent>
                <CardContent>
                      <Typography variant='body2' color='textSecondary' component='p'>
                          Author: {post.posterName ? post.posterName : 'No author'}
                      </Typography>
                </CardContent>
                <CardContent>
                      <Typography variant='body2' color='textSecondary' component='p'>
                          Likes: {post.numBinned ? post.numBinned.toString() : 'No Likes'}
                      </Typography>
                </CardContent>
                <br />
                  <button className={classes.button} onClick={() => {RemoveFromBin(post); window.location.reload()}}> Remove from bin </button>
                <br />
        </Card>
        </Grid>
    );
    };
  const { loading, error, data } = useQuery(queries.GETTOPTENBINNEDPOSTS, {
    fetchPolicy: 'cache-and-network'
  });
  let images;
  //console.log(data);
  if (data) {
    const { getTopTenBinnedPosts } = data;
    images = getTopTenBinnedPosts;
    //console.log(images);
  }
  let totallikes = 0;
  card = images && images.map((image)=>{
    totallikes += image.numBinned;
    return buildCard(image);
  });
  if (loading) {
    return <div>Loading</div>;
  } else if (error) {
    return <div>{error.message}</div>;
  } else if (data){
    
    return (
      <div>
          {totallikes > 200 ? <p className="popular">You are in mainstream!</p>:<p className="popular">You are in Non-mainstream :(</p>}
          <br />
        <Grid container className={classes.grid} spacing={5}>
          {card}
        </Grid>
      </div>
    );
  }
}

export default Popular;