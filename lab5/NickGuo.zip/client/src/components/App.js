import React from 'react';
import './App.css';
import { NavLink, BrowserRouter as Router, Route } from 'react-router-dom';
import Home from './Home';
import Bin from './Bin';
import Post from './Post';
import Form from './Form';
import Popular from './Popular';
import {
  ApolloClient,
  HttpLink,
  InMemoryCache,
  ApolloProvider
} from '@apollo/client';
const client = new ApolloClient({
  cache: new InMemoryCache(),
  link: new HttpLink({
    uri: 'http://localhost:4000'
  })
});

function App() {
  return (
    <ApolloProvider client={client}>
      <Router>
        <div>
          <header className="App-header">
            <h1 className="App-title">
              GraphQL With Apollo Client/Server Lab
            </h1>
            <nav>
              <NavLink className="navlink" to="/">
                Home
              </NavLink>
              <NavLink className="navlink" to="/my-bin">
                My Binned
              </NavLink>

              <NavLink className="navlink" to="/my-posts">
                My Posts
              </NavLink>
              <NavLink className="navlink" to="/popularity">
                Popular
              </NavLink>
            </nav>
          </header>
          <Route exact path="/" component={Home} />
          <Route path="/my-bin/" component={Bin} />
          <Route path="/my-posts/" component={Post} />
          <Route path="/new-post/" component={Form} />
          <Route path="/popularity/" component={Popular} />
        </div>
      </Router>
    </ApolloProvider>
  );
}

export default App;
