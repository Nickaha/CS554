import React, {useEffect, useState} from 'react';
import './App.css';
import { useMutation, useQuery } from '@apollo/client';
import queries from '../queries';

function isURL(str) {
    var pattern = new RegExp('^(https?:\\/\\/)?'+ // protocol
    '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.?)+[a-z]{2,}|'+ // domain name
    '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
    '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ // port and path
    '(\\?[;&a-z\\d%_.~+=-]*)?'+ // query string
    '(\\#[-a-z\\d_]*)?$','i'); // fragment locator
    return pattern.test(str);
}

function Form(){
    let validurl = false;
    let validpostername = false;
    const [uploadPost] = useMutation(queries.UPLOADIMAGE);
    const { loading, error, data } = useQuery(queries.USERPOSTEDIMAGES, {
        fetchPolicy: 'cache-and-network'
      });
    let images;
  //console.log(data);
    if (data) {
        const { userPostedImages } = data;
        images = userPostedImages;
        //console.log(images);
    }
    let description,url,posterName;

    return (
        <div>
            <form
                className="form"
                id="createpost"
                onSubmit={(e)=>{
                    e.preventDefault();
                    //console.log(url.value);
                    let notusedurl = true;
                    images.forEach((x)=>{
                        if(x.url === url.value) notusedurl = false;
                    })
                    if(url.value && isURL(url.value) && notusedurl ) validurl = true;
                    console.log(url.value, isURL(url.value), validurl);
                    if(posterName.value && posterName.value.trim().length>0) validpostername = true;
                    let uError = document.getElementById('uError');
                    let pNameError = document.getElementById('pError');
                    console.log(validurl,validpostername);
                    if(!validurl){
                        uError.hidden = false;
                    }
                    if(!validpostername) pNameError.hidden = false;
                    if(validurl && validpostername){
                        uError.hidden = true;
                        pNameError.hidden = true;
                        uploadPost({
                            variables:{
                                description: description.value,
                                url: url.value,
                                posterName:posterName.value
                            }
                        });
                        description.value='';
                        url.value = '';
                        posterName.value='';
                        validurl = false;
                        validpostername = false;
                        alert('Post created');
                    }
                }}>
                    <div className="form-group">
                        <label>
                            Description:
                            <br />
                            <input id="description"
                            ref={(node) => {
                                description = node;
                            }}
                            autoFocus={true}
                            />
                        </label>
                    </div>
                    <br />
                    <div className="form-group">
                        <label>
                            Image URL:
                            <br />
                            <input id="url"
                            ref={(node) => {
                                url = node;
                            }}
                            required
                            />
                        </label>
                        <div id="uError" className="error" hidden>
                            <p>
                                Valid url needs to be provided. Or this url might be posted before already
                            </p>
                        </div>
                    </div>
                    <br />
                    <div className="form-group">
                        <label>
                            Poster Name:
                            <br />
                            <input id="posterName"
                            ref={(node) => {
                                posterName = node;
                            }}
                            required
                            />
                        </label>
                        <div id="pError" className="error" hidden>
                            <p>
                                Valid poster name needs to be provided
                            </p>
                        </div>
                    </div>
                    <br />
                    <button className="button add-button" type="submit">
                        Submit
                    </button>
            </form>
        </div>
    );
}

export default Form;