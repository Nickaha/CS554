import logo from './pokemon.jpeg';
import './App.css';
import { NavLink, BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import React from 'react';
import ErrorBack from './Components/ErrorBack';
import Home from './Components/Home';
import Pokemon from './Components/Pokemon';
import PokemonList from './Components/PokemonList';
import Trainers from './Components/Trainers';
function App() {
  return (
    <Router>
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <h1 className="App-title">
          React, Redux, and Express For Pokemon Lab!
        </h1>
        <nav>
              <NavLink className="navlink" to="/">
                Home
              </NavLink>
              <NavLink className="navlink" to="/pokemon/page/0">
                Pokemon List
              </NavLink>
              <NavLink className="navlink" to="/trainers">
                Trainer
              </NavLink>
            </nav>
      </header>
      <br />
        <br />
        <div className="App-body">
          <Switch>
            <Route exact path="/" component={Home} />
            <Route exact path='/pokemon/page/:pagenum' component={PokemonList}/>
            <Route exact path='/pokemon/:id' component={Pokemon}/>
            <Route exact path='/trainers' component={Trainers}/>
            <Route exact path='/notFound' component={ErrorBack} status={404}/>
            <Route exact path="*" component={ErrorBack} status={404} />
          </Switch>
        </div>
      </div>
    </Router>
  );
}

export default App;
