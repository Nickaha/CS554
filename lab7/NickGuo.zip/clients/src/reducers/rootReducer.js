import { combineReducers } from 'redux';
import trainersReducer from './trainersReducer';
const rootReducer = combineReducers({
  trainers: trainersReducer
});

export default rootReducer;