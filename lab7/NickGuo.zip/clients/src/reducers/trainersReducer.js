import { v4 as uuid } from 'uuid';

const initalState = [
    {
      id: uuid(),
      name: 'Nick Guo',
      pokemons:[],
      selected: true
    }
];

let copyState = null;
let index = 0;

const userReducer = (state = initalState, action) => {
  const { type, payload } = action;

  switch (type) {
    case 'CREATE_TRAINER':
      console.log('payload', payload);
      return [
        ...state,
        { id: uuid(), name: payload.name, pokemons: [], selected : false}
      ];
    case 'DELETE_TRAINER':
      copyState = [...state];
      index = copyState.findIndex((x) => x.id === payload.id);
      if(copyState[index].selected === false){
        copyState.splice(index, 1);
      }
      return [...copyState];
    case 'CHANGE_SELECTED':
      copyState = [...state];
      index = copyState.findIndex((x) => x.id === payload.id);
      copyState.forEach((x)=>{
        x.selected = false;
      });
      copyState[index].selected = true;
      return [...copyState];
    case 'CATCH_POKEMON':
        copyState = [...state];
        index = copyState.findIndex((x) => x.id === payload.id);
        if (copyState[index].pokemons.length<6){
            copyState[index].pokemons.push(payload.pokemon);
        }
        return [...copyState];
    case 'RELEASE_POKEMON':
        copyState = [...state];
        index = copyState.findIndex((x) => x.id === payload.id);
        let copyPokemon = [...copyState[index].pokemons]
        let indexOfPokemon = copyPokemon.findIndex((x) => x.id.toString() === payload.pokemon.id.toString());
        copyPokemon.splice(indexOfPokemon,1);
        copyState[index].pokemons = copyPokemon;
        return copyState;
    default:
      return state;
  }
};

export default userReducer;