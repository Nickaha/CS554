const create_trainer = (name) =>({
    type: 'CREATE_TRAINER',
    payload: {
        name:name
    }
});

const delete_trainer = (id) => ({
    type: 'DELETE_TRAINER',
    payload:{
        id: id
    }
});

const change_selected = (id) =>({
    type: 'CHANGE_SELECTED',
    payload:{
        id: id
    }
});

const catchpokemon = (id, pokemon) =>({
    type: 'CATCH_POKEMON',
    payload:{
        id: id,
        pokemon: pokemon
    }
});

const releasepokemon = (id, pokemon) =>({
    type: 'RELEASE_POKEMON',
    payload:{
        id: id,
        pokemon: pokemon
    }
});

module.exports = {
    create_trainer,
    delete_trainer,
    change_selected,
    catchpokemon,
    releasepokemon
};
