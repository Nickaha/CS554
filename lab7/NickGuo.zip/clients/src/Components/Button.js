import React from 'react';
import { Link } from "react-router-dom";


const Button = (props) => {
    let link =`/${props.type}/page/`;
    let backlink,nextlink = link+'0';
    if(props.page){
        var pagenum = parseInt(props.page);
        if(pagenum>0){
            backlink = link + (pagenum-1).toString(); 
        }
        if(pagenum<props.max) nextlink = link+ (pagenum+1).toString();
    }
    if(pagenum>0 && pagenum<props.max){
        return (
            <div>
                <Link className="buttons-left" to={backlink}>Back</Link>
                
                <Link className="buttons-right" to={nextlink}>Next</Link>
            </div>
        );
    } else if (pagenum >0){
        return(
            <div>
                <Link className="buttons-left" to={backlink}>Back</Link>
            </div>
        );
    } else{
        return(
            <div>
                <Link className="buttons-right" to={nextlink}>Next</Link>
            </div>
        );
    }
};

export default Button;