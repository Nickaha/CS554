import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import axios from 'axios';
import { Link } from 'react-router-dom';
import Button from './Button';
import noImage from '../download.jpeg';
import ErrorBack from './ErrorBack';
import actions from '../actions';
import {
  Card,
  CardContent,
  CardMedia,
  Grid,
  Typography,
  makeStyles
} from '@material-ui/core';

import '../App.css';
const useStyles = makeStyles({
    card: {
      maxWidth: 250,
      height: 'auto',
      marginLeft: 'auto',
      marginRight: 'auto',
      borderRadius: 5,
      border: '1px solid #1e8678',
      boxShadow: '0 19px 38px rgba(0,0,0,0.30), 0 15px 12px rgba(0,0,0,0.22);'
    },
    titleHead: {
      borderBottom: '1px solid #1e8678',
      fontWeight: 'bold'
    },
    grid: {
      flexGrow: 1,
      flexDirection: 'row'
    },
    media: {
      height: '100%',
      width: '100%'
    },
    button: {
      color: '#faf0e6',
      fontWeight: 'bold',
      fontSize: 12,
      background:'#440f2b'
    }
  });

const PokemonList = (props) => {
    const regex = /(<([^>]+)>)/gi;
    const classes = useStyles();
    const [ loading, setLoading ] = useState(true);
    const [characterData, setCharacterData] = useState(undefined);
    const [pageNotThere, setPageNotThere] = useState(true);
    const [maxPage, setMaxPage] = useState(0);
    let card = null;
    const allTrainers = useSelector((state) => state.trainers);
    const dispatch = useDispatch();
    let currentTrainer = null;
    const catch_pokemon = (id, pokemon) =>{
        dispatch(actions.catchpokemon(id,pokemon));
    }
    const release_pokemon = (id,pokemon) =>{
        dispatch(actions.releasepokemon(id,pokemon));
    }


    useEffect(() => {
        setPageNotThere(true);
        setLoading(true);
        console.log('on load useeffect');
        async function fetchData() {
            try {
                setLoading(true);
                const { data } = await axios.get("http://localhost:4000/pokemon/page/"+props.match.params.pagenum);
                const max = Math.trunc(data.count/20);
                console.log(max);
                console.log(data);
                if (data.results && data.results.length!==0){
                    setCharacterData(data.results);
                    setPageNotThere(false);
                    setLoading(false);
                    setMaxPage(max);
                } else{
                    setCharacterData(data.results);
                    setPageNotThere(true);
                    console.log(loading);
                    setLoading(false);
                    console.log(loading);
                    
                }
                
            } catch (e) {
                console.log(e);
                setLoading(false);
                setPageNotThere(true);
            }
        }
        fetchData();
    }, [props.match.params.pagenum]);

    const buildCard = (character, img,id, caught, trainerid) => {
        return (
            <Grid item xs={12} sm={6} md={4} lg={3} xl={2} key={id}>
            <Card className={classes.card} variant="outlined">
                <Link to={`/pokemon/${id}`}>
                    <CardMedia
                    className={classes.media}
                    component="img"
                    image={
                        img
                          ? img
                          : noImage
                      }
                    title="Pokemon image"
                    />

                    <CardContent>
                    <Typography
                        className={classes.titleHead}
                        gutterBottom
                        variant="h6"
                        component="h2"
                    >
                        {character.name}
                    </Typography>
                    <Typography variant="body2" color="textSecondary" component="p">
                        {`Pokemon index #${id}`}
                    </Typography>
                    </CardContent>
                </Link>
                { 
                      caught === true ?
                      <button className={classes.button} onClick={() => {release_pokemon(trainerid, {id:id,name:character.name})}}> Release </button>:
                      <button className={classes.button} onClick={() => {catch_pokemon(trainerid, {id:id, name:character.name})}}> Catch </button> 
                }
            </Card>
            </Grid>
        );
        };
        allTrainers.forEach((trainer) =>{
            if(trainer.selected) currentTrainer = trainer;
        });
        console.log(currentTrainer);
        card =
            characterData &&
            characterData.map((character) => {
                let id = character.url.split('/')[6];
              let img = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${id}.png`;
              let caught = false;
              currentTrainer.pokemons.forEach((x)=>{
                if(id.toString() === x.id.toString()) caught = true;
              });
              return buildCard(character, img,id,caught,currentTrainer.id);
            });
        // var pagenum = parseInt(props.match.params.pagenum);
        // if(pagenum < 0 || pagenum>=38){
        //     return(
        //         <div>
        //             <Redirect to='/notfound'/>
        //         </div>
        //     );
        // }
        if (loading) {
            return (
                <div>
                <h2>Loading....</h2>
                </div>
            );
        }
        if(pageNotThere){
            return (
                <div>
                    <ErrorBack/>
                </div>
            );
        }
         else {
            return (
                <div>
                <br />
                <br />
                <Grid container className={classes.grid} spacing={5}>
                    {card}
                </Grid>
                <Button max = {maxPage} type={"pokemon"} page = {props.match.params.pagenum}/>
                </div>
            );
        }
}

export default PokemonList;