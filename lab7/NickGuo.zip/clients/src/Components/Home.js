import React from 'react';
import '../App.css';

const Home = () => {
  return (
    <div>
      <p className="hometext">
        This is a lab for React and Pokemon API to show the pokemon list information. You can click the 'Pokemon List', 'Pokemon', 'Trainer' link to see different information
      </p>

      <p className="hometext">
        This page is using Pokemon API
      </p>
    </div>
  );
};

export default Home;