import React from 'react';

const ErrorBack = () =>{
    return(
    <div>
        <h1>
        Error 404
        </h1>
        <p>
        Not Found
        </p>
    </div>
    );
};

export default ErrorBack;