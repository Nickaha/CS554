import React, { useState, useEffect } from 'react';
import axios from 'axios';
import noImage from '../download.jpeg';
import ErrorBack from './ErrorBack';
import { useDispatch, useSelector } from 'react-redux';
import actions from '../actions';
import {
    makeStyles,
    Card,
    CardContent,
    CardMedia,
    Typography,
    CardHeader
} from '@material-ui/core';
import '../App.css';
const useStyles = makeStyles({
    card: {
      maxWidth: 550,
      height: 'auto',
      marginLeft: 'auto',
      marginRight: 'auto',
      borderRadius: 5,
      border: '1px solid #1e8678',
      boxShadow: '0 19px 38px rgba(0,0,0,0.30), 0 15px 12px rgba(0,0,0,0.22);'
    },
    titleHead: {
      borderBottom: '1px solid #1e8678',
      fontWeight: 'bold'
    },
    grid: {
      flexGrow: 1,
      flexDirection: 'row'
    },
    media: {
      height: '100%',
      width: '100%'
    },
    button: {
        color: '#faf0e6',
        fontWeight: 'bold',
        fontSize: 12,
        background:'#440f2b'
    }
  });

const Pokemon = (props) => {
    const [characterData, setCharacterData] = useState('');
    const [loading, setLoading] = useState(true);
    const [pageNotExist, setPageNotExist] = useState(false);
    const classes = useStyles();
    const regex = /(<([^>]+)>)/gi;
    const allTrainers = useSelector((state) => state.trainers);
    const dispatch = useDispatch();
    let currentTrainer = null;
    const catch_pokemon = (id, pokemon) =>{
        dispatch(actions.catchpokemon(id,pokemon));
    }
    const release_pokemon = (id,pokemon) =>{
        dispatch(actions.releasepokemon(id,pokemon));
    }

    useEffect(() => {
        setPageNotExist(true);
        setLoading(true);
        console.log('useEffect fired');
        async function fetchData() {
            try {
                const { data } = await axios.get("http://localhost:4000/pokemon/"+props.match.params.id);
                //console.log(data);
                if(data){
                    setCharacterData(data);
                    setPageNotExist(false);
                    setLoading(false);
                } else{
                    setCharacterData(data);
                    setPageNotExist(true);
                    console.log(loading);
                    setLoading(false);
                    console.log(loading);
                    
                }
            } catch (e) {
                console.log(e);
                setLoading(false);
                setPageNotExist(true);
            }
        }
        fetchData();
    }, [props.match.params.id]);

    if (loading) {
        return (
            <div>
                <h2>Loading....</h2>
            </div>
        );
    } else if (pageNotExist) {
        return (
            <div>
                <ErrorBack/>
            </div>
        );
    } else {
        let thumb = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${characterData.id}.png`;
        allTrainers.forEach((trainer) =>{
            if(trainer.selected) currentTrainer = trainer;
        });
        console.log(currentTrainer);
        let caught = false;
        currentTrainer.pokemons.forEach((x)=>{
            if(characterData.id.toString() === x.id.toString()) caught = true;
            console.log(caught, characterData.id, x.id);
        });
        
        return (
            <Card className={classes.card} variant="outlined">
                <CardHeader className={classes.titleHead} title={characterData.name} />
                <CardMedia
                    className={classes.media}
                    component="img"
                    image={thumb? thumb: noImage}
                    title="Marvel image"
                />

                <CardContent>
                    <Typography variant="body2" color="textSecondary" component="div">
                        <span>
                            <strong className="title">Name:</strong>
                            <br/>
                            {characterData && characterData.name ? (
                                <span className="regulartext">{characterData.name.replace(regex, '')}</span>
                            ) : (
                                <span className="regulartext">No name</span>
                            )}
                        </span>
                        <br/>
                        <div>
                            <strong className="title">Types:</strong>
                            <br/>
                            {characterData && characterData.types && characterData.types.length >= 1 ? (
                                <ul>
                                    {characterData.types.map((pokemon) => {
                                        return <li key={pokemon.slot}><span>{pokemon.type.name}</span></li>
                                    })}
                                </ul>
                            ) : (
                                <span>N/A</span>
                            )}
                        </div>
                        <br/>
                        <div>
                        <strong className="title">Abilities:</strong>
                            <br/>
                            {characterData && characterData.abilities && characterData.abilities.length >= 1 ? (
                                <ul>
                                    {characterData.abilities.map((pokemon) => {
                                        return <li key={pokemon.slot}><span>{pokemon.ability.name}</span></li>
                                    })}
                                </ul>
                            ) : (
                                <span>N/A</span>
                            )}
                        </div>
                    </Typography>
                </CardContent>
                { 
                      caught === true ?
                      <button className={classes.button} onClick={() => {release_pokemon(currentTrainer.id, {id:characterData.id,name:characterData.name})}}> Release </button>:
                      <button className={classes.button} onClick={() => {catch_pokemon(currentTrainer.id, {id:characterData.id,name:characterData.name})}}> Catch </button> 
                }
            </Card>

        );
    }
};

export default Pokemon;
