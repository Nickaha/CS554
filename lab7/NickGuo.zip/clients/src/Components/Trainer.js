import { useDispatch } from 'react-redux';
import actions from '../actions';
import { Link } from 'react-router-dom';
import noImage from '../download.jpeg';
import '../App.css';
import {
    Card,
    CardContent,
    CardMedia,
    Grid,
    Typography,
    makeStyles
  } from '@material-ui/core';
  
  import '../App.css';
  const useStyles = makeStyles({
      card: {
        maxWidth: 250,
        height: 'auto',
        marginLeft: 'auto',
        marginRight: 'auto',
        borderRadius: 5,
        border: '1px solid #1e8678',
        boxShadow: '0 19px 38px rgba(0,0,0,0.30), 0 15px 12px rgba(0,0,0,0.22);'
      },
      titleHead: {
        borderBottom: '1px solid #1e8678',
        fontWeight: 'bold'
      },
      grid: {
        flexGrow: 1,
        flexDirection: 'row'
      },
      media: {
        height: '100%',
        width: '100%'
      },
      button: {
        color: '#1e8678',
        fontWeight: 'bold',
        fontSize: 12
      }
    });
function Trainer(props) {
    const classes = useStyles();
    const dispatch = useDispatch();
  
    const delete_trainer = () => {
      dispatch(actions.delete_trainer(props.trainer.id));
    };
    const selectTrainer = () =>{
        dispatch(actions.change_selected(props.trainer.id))
    };
    const buildCard = (character, img,id) => {
        return (
            <Grid item xs={12} sm={6} md={4} lg={3} xl={2} key={id}>
            <Card className={classes.card} variant="outlined">
                <Link to={`/pokemon/${id}`}>
                    <CardMedia
                    className={classes.media}
                    component="img"
                    image={
                        img
                          ? img
                          : noImage
                      }
                    title="Pokemon image"
                    />

                    <CardContent>
                    <Typography
                        className={classes.titleHead}
                        gutterBottom
                        variant="h6"
                        component="h2"
                    >
                        {character.name}
                    </Typography>
                    <Typography variant="body2" color="textSecondary" component="p">
                        {`Pokemon index #${id}`}
                    </Typography>
                    </CardContent>
                </Link>
            </Card>
            </Grid>
        );
        };
    let card = props.trainer.pokemons &&
    props.trainer.pokemons.map((character) => {
        let id = character.id;
      let img = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${id}.png`;
      return buildCard(character, img,id);
    });
    return (
      <div className="todo-wrapper">
        <table>
          <tbody>
            <tr>
              <td>Name:</td>
              <td>{props.trainer.name}</td>
              <br/>
              <td>Pokemons:</td>
              {card}
            { props.trainer.selected ?
            <td>
             <span>Selected</span>
             </td>
             :
              <td>
                <button onClick={selectTrainer}>Select Trainer</button>
              </td>
            }
            <br/>
              <td>
                <button onClick={delete_trainer}>Delete Trainer</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  }
  
  export default Trainer;
  